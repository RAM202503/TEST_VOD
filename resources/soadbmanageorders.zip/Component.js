sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("soa.db.manageorders.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map